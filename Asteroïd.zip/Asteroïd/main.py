from graphilibs import *
import math


class Objects:
    def __init__(self, x_start, y_start, grawin, *points):
        self.win = grawin
        self.coordo = [x_start, y_start]
        point_for_use = []
        is_x = True  # Utilisez un indicateur pour alterner entre x et y
        for point in points:
            if is_x:
                x = point + x_start
            else:
                y = point + y_start
                point_for_use.append(Point(x, y))  # Ajoutez le point (x, y) à la liste
            is_x = not is_x
        self.points = point_for_use
        self.polygon = Polygon(self.points)  # Store the polygon object
        self.polygon.draw(self.win)

    def calculate_center(self):
        x_sum = 0
        y_sum = 0
        for point in self.points:
            x_sum += point.getX()
            y_sum += point.getY()
        return Point(x_sum / len(self.points), y_sum / len(self.points))

    def move_obj(self, dx, dy):
        self.polygon.move(dx, dy)

    def rotate_obj(self, angle_deg):
        center = self.calculate_center()
        angle_rad = math.radians(angle_deg)  # Convert degrees to radians
        cos_val = math.cos(angle_rad)
        sin_val = math.sin(angle_rad)

        for point in self.points:
            x = point.getX() - center.getX()
            y = point.getY() - center.getY()
            new_x = x * cos_val - y * sin_val
            new_y = x * sin_val + y * cos_val
            point.move(new_x - point.getX(), new_y - point.getY())

class Player(Objects):
    def __init__(self, grawin):
        super().__init__(0, 0, grawin, 0, 30, -15, 0, 15, 0)


win = GraphWin()
win.setCoords(-272, -215, 272, 215)

player = Player(win)

while True:
    key = win.getKey()
    if key == 'z':
        player.move_obj(0, 10)  # Move up
    elif key == 's':
        player.move_obj(0, -10)  # Move down
    elif key == 'q':
        player.move_obj(-10, 0)  # Move left
    elif key == 'd':
        player.move_obj(10, 0)  # Move right
    elif key == 'a':
        player.rotate_obj(10)  # Rotate counter-clockwise by 10 degrees
    elif key == 'e':
        player.rotate_obj(-10)
    elif key == 'space':
        break

win.close()
